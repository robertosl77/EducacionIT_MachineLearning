LFWcrop es una versión recortada de Caras etiquetadas en la naturaleza (LFW)
conjunto de datos, manteniendo solo la parte central de cada imagen (es decir, la cara).
En la gran mayoría de imágenes se omite casi todo el fondo.

LFWcrop se creó debido a la preocupación por el mal uso del original
Conjunto de datos LFW, donde la precisión de la coincidencia de rostros puede ser poco realista
potenciado mediante el uso de partes de fondo de las imágenes (p. ej.
explotación de posibles correlaciones entre rostros y fondos).

Para cada imagen LFW, se extrajo el área dentro de un cuadro delimitador fijo.
El cuadro delimitador estaba en la misma ubicación para todas las imágenes, con la
las esquinas superior izquierda e inferior derecha son (83,92) y (166,175),
respectivamente. Luego, el área extraída se escaló a un tamaño de 64x64
píxeles. La selección de la ubicación del cuadro delimitador se basó en la
posiciones de 40 caras LFW seleccionadas al azar [1].

Como la ubicación y el tamaño de las caras en LFW se determinaron mediante
el uso de un localizador automático de caras (detector), las caras recortadas
en LFWcrop exhiben condiciones de la vida real, incluida la desalineación,
variaciones de escala, dentro y fuera del plano.

El directorio "faces" contiene todas las caras recortadas,
es decir, no hay subdirectorios para cada persona.

El directorio "lists" contiene archivos de texto que describen la asignación.
de caras en conjuntos, incluida la división en entrenamiento y prueba
subconjuntos dentro de cada conjunto. Los archivos de texto siguen el protocolo LFW [2].
El sufijo "diff" indica pares no coincidentes, donde cada línea contiene
los nombres de las imágenes de dos personas diferentes. El sufijo "same" indica
pares coincidentes, donde cada línea contiene los nombres de imágenes de la misma
persona.

Referencias

[1] C. Sanderson, B.C. Lovell.
    Multi-Region Probabilistic Histograms for Robust
    and Scalable Identity Inference.
    ICB 2009, LNCS 5558, pp. 199-208, 2009.

[2] G.B. Huang, M. Ramesh, T. Berg, E. Learned-Miller.
    Labeled Faces in the Wild: A Database for Studying
    Face Recognition in Unconstrained Environments.
    University of Massachusetts, Amherst, 
    Technical Report 07-49, 2007.
